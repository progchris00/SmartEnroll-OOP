﻿namespace Itec102.StudentManagementSystem
{
    public class SmartEnroll
    {
        static void Main()
        {
            Application.Run();
        }
    }
}